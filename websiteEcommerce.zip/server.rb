require 'stripe'
require 'sinatra'
require 'dotenv/load'
require 'json'
require 'securerandom'

# ============================================
# CONFIGURATION STRIPE
# ============================================

# Charge les clés depuis les variables d'environnement
Stripe.api_key = ENV['STRIPE_SECRET_KEY']

# Configuration du serveur
set :static, true
set :public_folder, 'public'
set :port, 4242
enable :sessions

# URL de votre domaine (à modifier en production)
YOUR_DOMAIN = ENV['YOUR_DOMAIN'] || 'http://localhost:4242'

# ============================================
# DONNÉES PRODUITS (fichier JSON)
# ============================================

# Charge les produits depuis le fichier JSON
products_file = File.join(File.dirname(__FILE__), 'produits.json')
products_data = JSON.parse(File.read(products_file))

PRODUCTS = products_data['products'].each_with_object({}) do |product, hash|
  hash[product['id']] = {
    name: product['name'],
    description: product['description'],
    price: product['price'],
    image: product['image'],
    currency: product['currency']
  }
end

# ============================================
# GESTION DES SESSIONS
# ============================================

before do
  session[:cart] ||= []
end

# ============================================
# ROUTES - PAGES
# ============================================

get '/' do
  send_file File.join(settings.public_folder, 'index.html')
end

get '/cart' do
  send_file File.join(settings.public_folder, 'checkout.html')
end

get '/success' do
  session[:cart] = []
  send_file File.join(settings.public_folder, 'success.html')
end

get '/cancel' do
  send_file File.join(settings.public_folder, 'cancel.html')
end

get '/admin' do
  # Vérifie si l'utilisateur est connecté
  if session[:admin_logged_in]
    send_file File.join(settings.public_folder, 'admin.html')
  else
    redirect '/admin/login'
  end
end

get '/admin/login' do
  send_file File.join(settings.public_folder, 'admin_login.html')
end

post '/admin/auth' do
  content_type :json
  
  data = JSON.parse(request.body.read)
  username = data['username']
  password = data['password']
  
  admin_user = ENV['ADMIN_USERNAME'] || 'admin'
  admin_pass = ENV['ADMIN_PASSWORD'] || 'admin123'
  
  # Debug logging (remove in production)
  puts "Login attempt - Username: #{username}, Expected: #{admin_user}"
  puts "Password match: #{password == admin_pass}"
  
  if username == admin_user && password == admin_pass
    session[:admin_logged_in] = true
    session[:admin_user] = username
    { success: true, redirect: '/admin' }.to_json
  else
    status 401
    { error: 'Identifiants invalides' }.to_json
  end
end

get '/admin/logout' do
  session[:admin_logged_in] = nil
  session[:admin_user] = nil
  redirect '/admin/login'
end

# ============================================
# API - GESTION DU PANIER
# ============================================

get '/api/cart' do
  content_type :json
  
  cart_items = session[:cart].map do |item|
    product = PRODUCTS[item['product_id']]
    next nil unless product
    
    {
      product_id: item['product_id'],
      name: product[:name],
      description: product[:description],
      price: product[:price],
      image: product[:image],
      quantity: item['quantity']
    }
  end.compact
  
  total = cart_items.sum { |item| item[:price] * item[:quantity] }
  
  {
    items: cart_items,
    total: total,
    currency: 'eur'
  }.to_json
end

get '/api/products' do
  content_type :json
  products = PRODUCTS.map do |id, data|
    {
      id: id,
      name: data[:name],
      description: data[:description],
      price: data[:price],
      image: data[:image],
      currency: data[:currency],
      active: data[:active]
    }
  end

  products.to_json
end

post '/api/cart/add' do
  content_type :json
  
  data = JSON.parse(request.body.read)
  product_id = data['product_id']
  quantity = (data['quantity'] || 1).to_i
  
  unless PRODUCTS.key?(product_id)
    return { error: 'Produit invalide' }.to_json
  end
  
  existing_item = session[:cart].find { |item| item['product_id'] == product_id }
  
  if existing_item
    existing_item['quantity'] += quantity
  else
    session[:cart] << {
      'product_id' => product_id,
      'quantity' => quantity
    }
  end
  
  {
    success: true,
    cart_size: session[:cart].sum { |item| item['quantity'] }
  }.to_json
end

post '/api/cart/update' do
  content_type :json
  
  data = JSON.parse(request.body.read)
  product_id = data['product_id']
  quantity = data['quantity'].to_i
  
  item = session[:cart].find { |item| item['product_id'] == product_id }
  
  if item
    if quantity <= 0
      session[:cart].reject! { |item| item['product_id'] == product_id }
    else
      item['quantity'] = quantity
    end
    { success: true }.to_json
  else
    { error: 'Produit non trouvé' }.to_json
  end
end

post '/api/cart/remove' do
  content_type :json
  
  data = JSON.parse(request.body.read)
  product_id = data['product_id']
  
  session[:cart].reject! { |item| item['product_id'] == product_id }
  
  { success: true }.to_json
end

post '/api/cart/clear' do
  content_type :json
  session[:cart] = []
  { success: true }.to_json
end

# ============================================
# API - ADMINISTRATION DES PRODUITS
# ============================================

# Middleware pour protéger les routes API admin
def require_admin
  unless session[:admin_logged_in]
    halt 401, { error: 'Non autorisé' }.to_json
  end
end

get '/api/admin/products' do
  require_admin
  content_type :json
  products_file = File.join(File.dirname(__FILE__), 'produits.json')
  products_data = JSON.parse(File.read(products_file))
  products_data['products'].to_json
end

post '/api/admin/products' do
  require_admin
  content_type :json
  
  begin
    data = JSON.parse(request.body.read)
    
    # Validation
    return { error: 'Le nom est requis' }.to_json unless data['name'] && !data['name'].empty?
    return { error: 'Le prix est requis' }.to_json unless data['price']
    
    products_file = File.join(File.dirname(__FILE__), 'produits.json')
    products_data = JSON.parse(File.read(products_file))
    
    # Génère un ID unique
    new_id = "prod_#{SecureRandom.hex(4)}"
    
    new_product = {
      'id' => new_id,
      'name' => data['name'],
      'description' => data['description'] || '',
      'price' => data['price'].to_i,
      'image' => data['image'] || 'https://via.placeholder.com/400',
      'currency' => data['currency'] || 'eur',
      'active' => data.fetch('active', true)
    }
    
    products_data['products'] << new_product
    
    File.write(products_file, JSON.pretty_generate(products_data))
    
    # Met à jour le cache PRODUCTS
    PRODUCTS[new_id] = {
      name: new_product['name'],
      description: new_product['description'],
      price: new_product['price'],
      image: new_product['image'],
      currency: new_product['currency']
    }
    
    { success: true, product: new_product }.to_json
    
  rescue JSON::ParserError => e
    status 400
    { error: 'JSON invalide' }.to_json
  rescue => e
    status 500
    { error: 'Erreur serveur: ' + e.message }.to_json
  end
end

put '/api/admin/products/:id' do
  require_admin
  content_type :json
  
  product_id = params[:id]
  
  begin
    data = JSON.parse(request.body.read)
    
    products_file = File.join(File.dirname(__FILE__), 'produits.json')
    products_data = JSON.parse(File.read(products_file))
    
    # Trouve le produit
    product_index = products_data['products'].find_index { |p| p['id'] == product_id }
    
    return { error: 'Produit non trouvé' }.to_json unless product_index
    
    # Met à jour le produit
    products_data['products'][product_index]['name'] = data['name'] if data['name']
    products_data['products'][product_index]['description'] = data['description'] if data['description']
    products_data['products'][product_index]['price'] = data['price'].to_i if data['price']
    products_data['products'][product_index]['image'] = data['image'] if data['image']
    products_data['products'][product_index]['currency'] = data['currency'] if data['currency']
    products_data['products'][product_index]['active'] = data['active'] if data.key?('active')
    
    File.write(products_file, JSON.pretty_generate(products_data))
    
    # Met à jour le cache PRODUCTS
    PRODUCTS[product_id] = {
      name: products_data['products'][product_index]['name'],
      description: products_data['products'][product_index]['description'],
      price: products_data['products'][product_index]['price'],
      image: products_data['products'][product_index]['image'],
      currency: products_data['products'][product_index]['currency']
    }
    
    { success: true, product: products_data['products'][product_index] }.to_json
    
  rescue JSON::ParserError => e
    status 400
    { error: 'JSON invalide' }.to_json
  rescue => e
    status 500
    { error: 'Erreur serveur: ' + e.message }.to_json
  end
end

delete '/api/admin/products/:id' do
  require_admin
  content_type :json
  
  product_id = params[:id]
  
  begin
    products_file = File.join(File.dirname(__FILE__), 'produits.json')
    products_data = JSON.parse(File.read(products_file))
    
    initial_length = products_data['products'].length
    # Supprime le produit
    products_data['products'].reject! { |p| p['id'] == product_id }
    
    return { error: 'Produit non trouvé' }.to_json unless products_data['products'].length < initial_length
    
    File.write(products_file, JSON.pretty_generate(products_data))
    
    # Supprime du cache PRODUCTS
    PRODUCTS.delete(product_id)
    
    { success: true }.to_json
    
  rescue => e
    status 500
    { error: 'Erreur serveur: ' + e.message }.to_json
  end
end

# ============================================
# CRÉATION SESSION STRIPE CHECKOUT
# ============================================

post '/create-checkout-session' do
  content_type :json
  
  begin
    cart = session[:cart]
    
    if cart.empty?
      return { error: 'Le panier est vide' }.to_json
    end
    
    line_items = cart.map do |item|
      product = PRODUCTS[item['product_id']]
      next nil unless product
      
      {
        price_data: {
          currency: product[:currency],
          product_data: {
            name: product[:name],
            description: product[:description],
            images: [product[:image]]
          },
          unit_amount: product[:price]
        },
        quantity: item['quantity']
      }
    end.compact
    
    session_obj = Stripe::Checkout::Session.create({
      payment_method_types: ['card'],
      line_items: line_items,
      mode: 'payment',
      success_url: YOUR_DOMAIN + '/success',
      cancel_url: YOUR_DOMAIN + '/cancel',
      shipping_address_collection: {
        allowed_countries: ['FR', 'BE', 'CH', 'CA', 'US']
      },
      billing_address_collection: 'required'
    })
    
    {
      sessionId: session_obj.id
    }.to_json
    
  rescue Stripe::AuthenticationError => e
    status 500
    { error: 'Erreur d\'authentification Stripe. Vérifiez votre clé API.' }.to_json
  rescue Stripe::InvalidRequestError => e
    status 400
    { error: 'Requête invalide: ' + e.message }.to_json
  rescue => e
    status 500
    { error: 'Erreur serveur: ' + e.message }.to_json
  end
end

# ============================================
# WEBHOOK STRIPE
# ============================================

post '/webhook' do
  payload = request.body.read
  sig_header = request.env['HTTP_STRIPE_SIGNATURE']
  endpoint_secret = ENV['STRIPE_WEBHOOK_SECRET']
  
  begin
    event = Stripe::Webhook.construct_event(
      payload, sig_header, endpoint_secret
    )
    
    case event.type
    when 'checkout.session.completed'
      session_data = event.data.object
      puts "Paiement réussi pour la session: #{session_data.id}"
    when 'payment_intent.payment_failed'
      puts "Paiement échoué: #{event.data.object.id}"
    else
      puts "Événement non géré: #{event.type}"
    end
    
    status 200
    { received: true }.to_json
    
  rescue Stripe::SignatureVerificationError => e
    status 400
    { error: 'Signature webhook invalide' }.to_json
  rescue => e
    status 500
    { error: 'Erreur webhook: ' + e.message }.to_json
  end
end

# ============================================
# ERREURS
# ============================================

not_found do
  content_type :json
  { error: 'Page non trouvée' }.to_json
end

error do
  content_type :json
  { error: 'Erreur serveur: ' + env['sinatra.error'].message }.to_json
end