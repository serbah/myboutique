/**
 * cart.js - Gestion du panier e-commerce
 * 
 * Ce fichier gère:
 * - Le stockage du panier en localStorage
 * - L'ajout/suppression/modification de produits
 * - La communication avec le backend Sinatra
 * - L'initialisation de Stripe Checkout
 */

// ============================================
// CONFIGURATION
// ============================================

const CART_STORAGE_KEY = 'ecommerce_cart';
const STRIPE_PUBLIC_KEY = typeof window !== 'undefined' ? (window.STRIPE_PUBLIC_KEY || '') : '';

// ============================================
// FONCTIONS UTILITAIRES
// ============================================

/**
 * Formate un prix en centimes vers le format euros
 * @param {number} cents - Prix en centimes
 * @returns {string} Prix formaté (ex: "199.00 €")
 */
function formatPrice(cents) {
  return (cents / 100).toFixed(2) + ' €';
}

/**
 * Affiche une notification temporaire
 * @param {string} message - Message à afficher
 * @param {string} type - Type de message (success, error, info)
 */
function showNotification(message, type = 'success') {
  const notification = document.createElement('div');
  notification.className = `notification notification-${type}`;
  notification.innerHTML = `
    <i class="fas fa-${type === 'success' ? 'check-circle' : 'exclamation-circle'}"></i>
    <span>${message}</span>
  `;
  
  document.body.appendChild(notification);
  
  // Animation d'entrée
  requestAnimationFrame(() => {
    notification.classList.add('show');
  });
  
  // Suppression automatique
  setTimeout(() => {
    notification.classList.remove('show');
    setTimeout(() => notification.remove(), 300);
  }, 3000);
}

// ============================================
// GESTION DU PANIER (LOCALSTORAGE)
// ============================================

/**
 * Récupère le panier depuis localStorage
 * @returns {Array} Tableau des articles du panier
 */
function getCart() {
  const cartData = localStorage.getItem(CART_STORAGE_KEY);
  return cartData ? JSON.parse(cartData) : [];
}

/**
 * Sauvegarde le panier dans localStorage
 * @param {Array} cart - Tableau des articles
 */
function saveCart(cart) {
  localStorage.setItem(CART_STORAGE_KEY, JSON.stringify(cart));
  updateCartCount();
}

/**
 * Met à jour le compteur du panier dans le header
 */
function updateCartCount() {
  const cart = getCart();
  const count = cart.reduce((sum, item) => sum + item.quantity, 0);
  
  const countElements = document.querySelectorAll('#cart-count');
  countElements.forEach(el => {
    el.textContent = count;
  });
  
  // Déclenche un événement personnalisé pour les autres composants
  window.dispatchEvent(new CustomEvent('cartUpdated', { detail: { count } }));
}

/**
 * Ajoute un produit au panier
 * @param {string} productId - ID du produit
 * @param {number} quantity - Quantité à ajouter (défaut: 1)
 * @returns {Promise<object>} Résultat de l'opération
 */
async function addToCart(productId, quantity = 1) {
  const cart = getCart();
  const existingItem = cart.find(item => item.product_id === productId);
  
  if (existingItem) {
    existingItem.quantity += quantity;
  } else {
    cart.push({
      product_id: productId,
      quantity: quantity
    });
  }
  
  saveCart(cart);
  showNotification('Produit ajouté au panier !');
  
  // Optionnel:同步 vers le backend
  try {
    await fetch('/api/cart/add', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ product_id: productId, quantity })
    });
  } catch (e) {
    // Ignore les erreurs de sync - le panier local prime
  }
  
  return { success: true, cart_size: cart.length };
}

/**
 * Met à jour la quantité d'un produit
 * @param {string} productId - ID du produit
 * @param {number} quantity - Nouvelle quantité
 */
function updateQuantity(productId, quantity) {
  const cart = getCart();
  const item = cart.find(i => i.product_id === productId);
  
  if (item) {
    if (quantity <= 0) {
      // Supprime le produit si quantité = 0
      removeFromCart(productId);
    } else {
      item.quantity = quantity;
      saveCart(cart);
    }
  }
}

/**
 * Supprime un produit du panier
 * @param {string} productId - ID du produit
 */
function removeFromCart(productId) {
  const cart = getCart().filter(item => item.product_id !== productId);
  saveCart(cart);
  showNotification('Produit supprimé du panier');
}

/**
 * Vide complètement le panier
 */
function clearCart() {
  if (confirm('Voulez-vous vraiment vider le panier ?')) {
    localStorage.removeItem(CART_STORAGE_KEY);
    updateCartCount();
    showNotification('Panier vidé');
    
    // Sync avec le backend
    fetch('/api/cart/clear', { method: 'POST' }).catch(() => {});
  }
}

// ============================================
// CALCUL DU TOTAL
// ============================================

/**
 * Calcule le total du panier
 * @param {Array} cart - Panier
 * @param {object} productsMap - Map des produits
 * @returns {number} Total en centimes
 */
function calculateTotal(cart, productsMap) {
  return cart.reduce((total, item) => {
    const product = productsMap[item.product_id];
    return total + (product ? product.price * item.quantity : 0);
  }, 0);
}

// ============================================
// PAIEMENT STRIPE
// ============================================

/**
 * Initialise Stripe avec la clé publique
 * @returns {Stripe} Instance Stripe
 */
function initStripe() {
  if (typeof Stripe === 'undefined') {
    console.error('Stripe.js non chargé');
    return null;
  }
  return Stripe(STRIPE_PUBLIC_KEY);
}

/**
 * Lance le processus de paiement
 * @returns {Promise<void>}
 */
async function processCheckout() {
  const cart = getCart();
  
  if (cart.length === 0) {
    showNotification('Le panier est vide', 'error');
    return;
  }
  
  const btn = document.getElementById('checkout-btn');
  if (btn) {
    btn.disabled = true;
    btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Redirection...';
  }
  
  try {
    // Appelle le backend pour créer une session Stripe
    const response = await fetch('/create-checkout-session', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ cart })
    });
    
    const data = await response.json();
    
    if (data.error) {
      throw new Error(data.error);
    }
    
    // Utilise Stripe Checkout pour la redirection
    const stripe = initStripe();
    if (stripe && data.sessionId) {
      const { error } = await stripe.redirectToCheckout({
        sessionId: data.sessionId
      });
      
      if (error) {
        throw new Error(error.message);
      }
    } else {
      // Fallback: redirection manuelle si Stripe non disponible
      window.location.href = data.url || '/success';
    }
    
  } catch (error) {
    console.error('Erreur paiement:', error);
    showNotification('Erreur: ' + error.message, 'error');
    
    if (btn) {
      btn.disabled = false;
      btn.innerHTML = '<i class="fas fa-credit-card"></i> Procéder au paiement';
    }
  }
}

// ============================================
// CHARGEMENT DES PRODUITS DEPUIS L'API
// ============================================

/**
 * Charge la liste des produits depuis l'API
 * @returns {Promise<Array>} Liste des produits
 */
async function loadProducts() {
  try {
    const response = await fetch('/api/products');
    return await response.json();
  } catch (error) {
    console.error('Erreur chargement produits:', error);
    return [];
  }
}

/**
 * Crée une map des produits pour un accès rapide
 * @param {Array} products - Liste des produits
 * @returns {object} Map produit_id => produit
 */
function createProductsMap(products) {
  const map = {};
  products.forEach(p => map[p.id] = p);
  return map;
}

// ============================================
// INITIALISATION
// ============================================

// Met à jour le compteur au chargement
document.addEventListener('DOMContentLoaded', () => {
  updateCartCount();
});

// Expose les fonctions globalement
window.ecommerceCart = {
  getCart,
  saveCart,
  addToCart,
  updateQuantity,
  removeFromCart,
  clearCart,
  formatPrice,
  processCheckout,
  loadProducts,
  showNotification
};