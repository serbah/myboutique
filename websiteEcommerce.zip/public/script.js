document.addEventListener('DOMContentLoaded', () => {
  const productsGrid = document.getElementById('products-grid');
  const loadingElem = productsGrid ? productsGrid.querySelector('.loading') : null;
  if (!productsGrid) return;

  async function loadProducts() {
    try {
      const response = await fetch('/api/products');
      if (!response.ok) {
        throw new Error('Erreur ' + response.status);
      }

      const products = await response.json();
      if (loadingElem) loadingElem.remove();

      const activeProducts = Array.isArray(products)
        ? products.filter(product => product.active !== false)
        : [];

      if (activeProducts.length === 0) {
        productsGrid.innerHTML = '<p class="empty-state">Aucun produit disponible pour le moment.</p>';
        return;
      }

      productsGrid.innerHTML = activeProducts.map(product => `
        <article class="product-card">
          <div class="product-image">
            <img src="${product.image}" alt="${product.name}">
          </div>
          <div class="product-info">
            <h3>${product.name}</h3>
            <p class="product-description">${product.description || ''}</p>
            <p class="product-price">${formatProductPrice(product.price, product.currency)}</p>
            <button class="add-btn" type="button" onclick="addToCart('${product.id}')">
              <i class="fas fa-cart-plus"></i> Ajouter au panier
            </button>
          </div>
        </article>
      `).join('');

      updateCartCount();
    } catch (error) {
      console.error('Erreur de chargement des produits:', error);
      if (loadingElem) loadingElem.remove();
      productsGrid.innerHTML = '<p class="empty-state">Impossible de charger les produits. Vérifiez le serveur.</p>';
    }
  }

  loadProducts();
});

function formatProductPrice(price, currency) {
  if (currency === 'eur') {
    return formatPrice(price);
  }

  if (currency === 'usd') {
    return '$' + (price / 100).toFixed(2);
  }

  return `${price} ${currency ? currency.toUpperCase() : ''}`;
}
